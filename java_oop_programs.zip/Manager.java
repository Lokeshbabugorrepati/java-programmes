class Employee {
    String name;
    double salary;

    Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    void show() {
        System.out.println(name + " earns " + salary);
    }
}

public class Manager extends Employee {
    double bonus;

    Manager(String name, double salary, double bonus) {
        super(name, salary);
        this.bonus = bonus;
    }

    void show() {
        super.show();
        System.out.println("Bonus: " + bonus);
    }

    public static void main(String[] args) {
        Manager m = new Manager("Chandu", 70000, 10000);
        m.show();
    }
}
