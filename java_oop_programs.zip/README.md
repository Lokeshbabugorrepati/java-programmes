# Java OOP Programs

This repository contains a collection of simple Java programs demonstrating core Object-Oriented Programming concepts:

## List of Programs
1. **Student.java** - Encapsulation with getter methods
2. **BankAccount.java** - Banking operations using encapsulation
3. **Manager.java** - Inheritance and method overriding
4. **TestPolymorphism.java** - Runtime polymorphism
5. **Shape.java** - Abstraction using abstract class
6. **Bike.java** - Interface implementation
7. **Car.java** - Constructor overloading
8. **Library.java** - Composition using array of objects

Feel free to use or modify these examples for learning or posting on GitHub.
